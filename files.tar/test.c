void func(char* s, int i) {
    short* vga = (short*) 0xb8000;
    vga[0] = 0x2800 | s[i];
    return;
}

void func2(char* s, int i) {
    short* vga = (short*) 0xb8000;
    vga[0] = 0x2800 | s[i];
    return;
}

void main(void) {
    func("i can call functions", 2);
    func("i can call functions", 0);
    return;
}
