__asm__("jmp main");

#include <stdio.h>

void main(void) {
    char s[] = "hello";
    puts(s);
    return;
}
